export const brand = {
  wordmark: "/LetLois_Logo_Wide_Lapels_Blue_Transparent_(2).png",

  mark: "/LetLois_Logo_Woman_Wide_Lapels_Blue_Transparent.png",

  onboardingUrl: 'onboarding.letlois.com',
  supportEmail: 'info@letlois.com',
  supportPhone: '+16024618204',
  supportPhoneDisplay: '(602) 461-8204'
};
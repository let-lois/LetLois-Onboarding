import React, { useEffect, useState } from 'react';
import { Link, Navigate, useParams } from 'react-router-dom';
import { ArrowRightIcon, ChevronLeftIcon } from 'lucide-react';
import { pages, getPageBySlug } from '../data/pages';
import { FormEmbed } from '../components/FormEmbed';

export function FormScreen() {
  const { slug = '' } = useParams();
  const page = getPageBySlug(slug);

  // True while the form inside the iframe is uploading or filing its answers.
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [slug]);

  // The form tells us how its submit is going, so nobody leaves mid-upload.
  useEffect(() => {
    setBusy(false);
    if (!page?.formEmbedUrl) return;
    const formOrigin = new URL(page.formEmbedUrl).origin;
    const onMessage = (e: MessageEvent) => {
      if (e.origin !== formOrigin) return;
      const data = e.data;
      if (!data || data.source !== 'letlois-onboarding') return;
      if (data.type === 'busy') setBusy(true);
      else if (data.type === 'done' || data.type === 'error') setBusy(false);
    };
    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [slug]);

  // Closing the tab mid-upload would stop it, so ask first.
  useEffect(() => {
    if (!busy) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [busy]);

  const leaveCheck = (e: React.MouseEvent) => {
    if (busy && !window.confirm('Your files are still uploading. If you leave now, the upload will stop. Leave anyway?')) {
      e.preventDefault();
    }
  };

  if (!page || !page.formEmbedUrl) return <Navigate to={`/${pages[0].slug}`} replace />;

  const index = pages.findIndex((p) => p.id === page.id);
  const next = pages[index + 1];

  return (
    <div className="w-full pb-14 pt-3 sm:pb-20 sm:pt-6">
      <div className="mx-auto flex w-full max-w-4xl items-center justify-between gap-4 px-4 sm:px-8">
        <Link
          to={`/${page.slug}`}
          onClick={leaveCheck}
          className="inline-flex items-center gap-1 rounded text-[12px] font-medium text-white/25 transition-colors duration-150 ease-smooth hover:text-white/60 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-300">
          
          <ChevronLeftIcon className="h-3.5 w-3.5" aria-hidden="true" />
          Back to the video
        </Link>
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-brand-200 sm:text-xs">
          {page.eyebrow} form
        </p>
      </div>

      <h1 className="mx-auto mt-3 max-w-4xl px-4 text-xl font-extrabold leading-tight tracking-tight text-white sm:mt-5 sm:px-8 sm:text-3xl">
        {page.title}
      </h1>

      <div className="mt-4 sm:mt-6">
        <FormEmbed
          src={page.formEmbedUrl}
          title={`${page.eyebrow} onboarding form`} />
        
      </div>

      {next &&
      <div className="mx-auto mt-6 flex w-full max-w-4xl flex-col items-center gap-2 px-4 sm:mt-8 sm:px-8">
          {busy ?
        <button
          type="button"
          disabled
          className="inline-flex w-full cursor-not-allowed items-center justify-center gap-2 rounded-full bg-white/10 px-6 py-3.5 text-base font-semibold text-white/50 sm:w-auto sm:px-8">
          
              Still uploading — keep this page open
            </button> :

        <Link
          to={`/${next.slug}`}
          className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-6 py-3.5 text-base font-semibold text-white transition-colors duration-150 ease-smooth hover:bg-brand-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-300 focus-visible:ring-offset-2 focus-visible:ring-offset-ink-900 sm:w-auto sm:px-8">
          
            I&apos;ve submitted this — continue
            <ArrowRightIcon className="h-4 w-4" aria-hidden="true" />
          </Link>
        }
          <p className="text-[12px] text-white/35">
            {busy ?
          'You can continue as soon as the upload finishes.' :
          "Only continue once you've hit submit on the form above."}
          </p>
        </div>
      }
    </div>);

}
import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronDownIcon, MailIcon, PhoneIcon } from 'lucide-react';
import { brand } from '../data/brand';

export function ContactMenu() {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onPointer = (e: MouseEvent | TouchEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onPointer);
    document.addEventListener('touchstart', onPointer);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onPointer);
      document.removeEventListener('touchstart', onPointer);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const options = [
  {
    href: `tel:${brand.supportPhone}`,
    icon: PhoneIcon,
    label: 'Call us',
    value: brand.supportPhoneDisplay
  },
  {
    href: `mailto:${brand.supportEmail}`,
    icon: MailIcon,
    label: 'Email us',
    value: brand.supportEmail
  }];


  return (
    <div ref={rootRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="menu"
        className="inline-flex items-center gap-1 rounded text-[13px] font-semibold text-brand-300 transition-colors duration-150 ease-smooth hover:text-brand-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 sm:text-sm">
        
        Contact Team
        <ChevronDownIcon
          className={`h-3.5 w-3.5 transition-transform duration-200 ease-smooth ${
          open ? 'rotate-180' : ''}`
          }
          aria-hidden="true" />
        
      </button>

      <AnimatePresence>
        {open &&
        <motion.div
          role="menu"
          initial={{ opacity: 0, scale: 0.96, y: -4 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.98, y: -2 }}
          transition={{ duration: 0.16, ease: [0.23, 1, 0.32, 1] }}
          style={{ transformOrigin: 'top right' }}
          className="absolute right-0 top-full z-40 mt-2 w-64 overflow-hidden rounded-xl border border-white/10 bg-ink-850 p-1.5 shadow-[0_18px_50px_-20px_rgba(0,0,0,0.9)]">
          
            {options.map(({ href, icon: Icon, label, value }) =>
          <a
            key={href}
            href={href}
            role="menuitem"
            onClick={() => setOpen(false)}
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 transition-colors duration-150 ease-smooth hover:bg-white/[0.05] focus:outline-none focus-visible:bg-white/[0.06]">
            
                <span className="flex h-8 w-8 flex-none items-center justify-center rounded-lg bg-brand-500/12 text-brand-300 ring-1 ring-inset ring-brand-400/25">
                  <Icon className="h-4 w-4" aria-hidden="true" />
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-semibold text-white">{label}</span>
                  <span className="block truncate text-[13px] text-white/50">{value}</span>
                </span>
              </a>
          )}
          </motion.div>
        }
      </AnimatePresence>
    </div>);

}
import React from 'react';

interface FormEmbedProps {
  src: string;
  title: string;
}

/** Full-bleed embedded onboarding form, sized to fill the screen below the header. */
export function FormEmbed({ src, title }: FormEmbedProps) {
  return (
    <div className="w-full overflow-hidden border-y border-white/10 bg-white sm:mx-auto sm:max-w-4xl sm:rounded-2xl sm:border">
      <iframe
        src={src}
        title={title}
        allow="screen-wake-lock"
        className="block h-[calc(100vh-160px)] min-h-[700px] w-full border-0" />
      
    </div>);

}
import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { OnboardingScreen } from './pages/OnboardingScreen';
import { FormScreen } from './pages/FormScreen';
import { pages } from './data/pages';

export function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Navigate to={`/${pages[0].slug}`} replace />} />
          <Route path="/:slug" element={<OnboardingScreen />} />
          <Route path="/:slug/form" element={<FormScreen />} />
          <Route path="*" element={<Navigate to={`/${pages[0].slug}`} replace />} />
        </Routes>
      </Layout>
    </BrowserRouter>);

}